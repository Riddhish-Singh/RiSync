const express = require("express")
const cors = require("cors")
const scrapeAmazon = require("../scraper/amazon")
const fs = require("fs")

const app = express()

app.use(cors())

app.get("/search", async (req,res)=>{

const keyword = req.query.keyword

await scrapeAmazon(keyword)

const data = JSON.parse(fs.readFileSync("data/products.json"))

res.json(data)

})

app.listen(5000,()=>{

console.log("Server running on port 5000")

})