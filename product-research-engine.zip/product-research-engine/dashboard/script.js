async function search(){

const keyword = document.getElementById("keyword").value

const response = await fetch(`http://localhost:5000/search?keyword=${keyword}`)

const products = await response.json()

let html=""

products.forEach(p=>{

html+=`

<div class="card">

<h3>${p.title}</h3>
<p>Price: ₹${p.price}</p>
<p>${p.rating}</p>

</div>

`

})

document.getElementById("results").innerHTML=html

}