const { chromium } = require("playwright")
const fs = require("fs")

async function scrapeAmazon(keyword){

const browser = await chromium.launch({headless:true})
const page = await browser.newPage()

await page.goto(`https://www.amazon.in/s?k=${keyword}`)

await page.waitForSelector("h2")

const products = await page.evaluate(()=>{

const items = document.querySelectorAll(".s-result-item")

let data = []

items.forEach(item=>{

const title = item.querySelector("h2 span")?.innerText
const price = item.querySelector(".a-price-whole")?.innerText
const rating = item.querySelector(".a-icon-alt")?.innerText

if(title){

data.push({
title,
price,
rating
})

}

})

return data.slice(0,20)

})

fs.writeFileSync("data/products.json",JSON.stringify(products,null,2))

await browser.close()

}

module.exports = scrapeAmazon