const express = require("express");
const { chromium } = require("playwright");

const app = express();

app.get("/search", async (req, res) => {

const keyword = req.query.keyword || "chips";

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage();

let results = [];


// AMAZON
await page.goto(`https://www.amazon.in/s?k=${keyword}`);
await page.waitForSelector("h2");

const amazon = await page.evaluate(()=>{
let data=[]
document.querySelectorAll(".s-result-item").forEach(item=>{
const title=item.querySelector("h2 span")?.innerText
const price=item.querySelector(".a-price-whole")?.innerText
if(title){
data.push({site:"Amazon",title,price})
}
})
return data.slice(0,5)
})

results.push(...amazon)


// FLIPKART
await page.goto(`https://www.flipkart.com/search?q=${keyword}`);
await page.waitForTimeout(5000);

const flipkart = await page.evaluate(()=>{
let data=[]
document.querySelectorAll("a").forEach(item=>{
const title=item.innerText
if(title && title.length>20){
data.push({site:"Flipkart",title})
}
})
return data.slice(0,5)
})

results.push(...flipkart)


// BLINKIT
await page.goto(`https://blinkit.com/s/?q=${keyword}`);
await page.waitForTimeout(5000);

const blinkit = await page.evaluate(()=>{
let data=[]
document.querySelectorAll("h3").forEach(item=>{
const title=item.innerText
if(title){
data.push({site:"Blinkit",title})
}
})
return data.slice(0,5)
})

results.push(...blinkit)


// ZEPTO
await page.goto(`https://www.zeptonow.com/search?query=${keyword}`);
await page.waitForTimeout(5000);

const zepto = await page.evaluate(()=>{
let data=[]
document.querySelectorAll("h5").forEach(item=>{
const title=item.innerText
if(title){
data.push({site:"Zepto",title})
}
})
return data.slice(0,5)
})

results.push(...zepto)

await browser.close();

res.json(results);

});

app.listen(5000,()=>{
console.log("Server running on http://localhost:5000");
});